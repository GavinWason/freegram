@component('mail::message')
# Welcome to freeCodeGram


this is a community of fellow developers and we love that you thave joined us.


All the best,<br>
{{ config('app.name') }}
@endcomponent
